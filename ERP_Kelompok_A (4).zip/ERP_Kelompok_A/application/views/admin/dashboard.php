<!-- Konten utama -->
<div class="content">
    <h1>Dashboard Admin</h1>
    <p>Selamat datang, <?php echo $this->session->userdata('username'); ?>!</p>

    <!-- Kartu Statistik -->
    <div class="dashboard-cards" style="display: flex; gap: 20px; flex-wrap: wrap;">
        <div class="card" style="flex: 1; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #e67e22">
            <h3>Total Produk</h3>
            <p><?php echo count($products); ?> Produk</p>
        </div>
        <div class="card" style="flex: 1; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #e67e22">
            <h3>Total Pelanggan</h3>
            <p><?php echo $total_customers; ?> Pelanggan</p>
        </div>
        <div class="card" style="flex: 1; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #e67e22">
            <h3>Total Supplier</h3>
            <p><?php echo $total_suppliers; ?> Supplier</p>
        </div>
    </div>

    <!-- Card untuk Grafik Penjualan -->
    <div class="card" style="flex: 1 100%; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #000; margin-top: 20px; margin-bottom:50px;">
        <h3>Grafik Penjualan</h3>
        <!-- Container Grafik -->
        <div class="chart-container" style="position: relative; width: 100%; height: 300px;">
            <canvas id="salesChart"></canvas>
        </div>
    </div>

    <script>
    // Menggunakan Chart.js untuk menampilkan grafik penjualan
    var ctx = document.getElementById('salesChart').getContext('2d');
    var salesChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($months); ?>, // Contoh data bulan
            datasets: [{
                label: 'Penjualan', // Label dataset
                data: <?php echo json_encode($sales_data); ?>, // Contoh data penjualan
                backgroundColor: 'rgba(243, 156, 18, 0.8)', // Warna #f39c12 yang lebih terang dengan transparansi 0.8
                borderColor: 'rgba(0, 0, 0, 0.1)', // Warna border
                borderWidth: 1
            }]
        },
        options: {
            responsive: true, // Membuat grafik responsif
            maintainAspectRatio: false, // Menjaga rasio aspek canvas
            plugins: {
                legend: {
                    labels: {
                        color: 'white' // Mengubah warna teks label legend ("Penjualan") menjadi putih
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    ticks: {
                        color: 'white' // Mengubah warna teks label bulan menjadi putih
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: 'white' // Mengubah warna teks label sumbu Y menjadi putih
                    }
                }
            }
        }
    });
</script>

