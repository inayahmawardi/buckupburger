<div class="sidebar">
    <div class="sidebar-header">
        <img src="<?php echo base_url('assets/logo/logo_buckup.png'); ?>" alt="Logo" class="logo"> <!-- Ganti dengan path logo Anda -->
        <h2>Admin Panel</h2>
    </div>
    <ul>
        <li><a href="<?php echo site_url('dashboard'); ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="<?php echo site_url('dashboard/customers'); ?>"><i class="fas fa-users"></i> Customers</a></li>
        <li><a href="<?php echo site_url('dashboard/suppliers'); ?>"><i class="fas fa-truck"></i> Suppliers</a></li>
        <li><a href="<?php echo site_url('dashboard/products'); ?>"><i class="fas fa-box"></i> Products</a></li>
        <li><a href="<?php echo site_url('dashboard/transaksi'); ?>"><i class="fas fa-money-bill-wave"></i> Transaksi</a></li>
        <li><a href="<?php echo site_url('dashboard/profile'); ?>"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="javascript:void(0);" onclick="showLogoutModal()"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
     
    </ul>
</div>

<!-- Modal Konfirmasi Logout -->
<div id="logoutModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeLogoutModal()">&times;</span>
        <h3>Konfirmasi Logout</h3>
        <p>Apakah Anda yakin ingin logout?</p>
        <div class="modal-actions">
            <button class="btn-logout" onclick="logout()">Logout</button>
            <button class="btn-cancel" onclick="closeLogoutModal()">Batal</button>
        </div>
    </div>
</div>