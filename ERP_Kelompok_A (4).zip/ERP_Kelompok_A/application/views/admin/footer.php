   <!-- Footer -->
   <div class="footer">
            <p>&copy; 2024 Avid Burger | All Rights Reserved.</p>
        </div>
    </div>

    <!-- JavaScript untuk Fungsi Sidebar dan Modal -->
    <script>
        function showLogoutModal() {
            document.getElementById("logoutModal").style.display = "block";
        }

        function closeLogoutModal() {
            document.getElementById("logoutModal").style.display = "none";
        }

        function logout() {
            window.location.href = "<?php echo site_url('dashboard/logout'); ?>";
        }

        window.onclick = function(event) {
            var modal = document.getElementById("logoutModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Fungsi untuk toggle sidebar (menyembunyikan dan menampilkan)
        function toggleSidebar() {
            var sidebar = document.getElementById('sidebar');
            if (sidebar.style.display === 'none') {
                sidebar.style.display = 'block';
            } else {
                sidebar.style.display = 'none';
            }
        }
    </script>

<script>

   // Fungsi untuk menghapus customer
function deleteCustomer(customerId) {
    // Menyimpan id customer yang ingin dihapus ke dalam modal
    document.getElementById('confirmDeleteCustomerBtn').onclick = function() {
        // Kirim request untuk menghapus customer (misalnya melalui AJAX atau redirect ke controller)
        window.location.href = "<?php echo site_url('dashboard/do_delete_customer/'); ?>" + customerId;
    };

    // Menampilkan modal delete
    $('#deleteCustomerModal').modal('show');
}

function deleteSupplier(supplierId) {
    // Menyimpan id customer yang ingin dihapus ke dalam modal
    document.getElementById('confirmDeleteSupplierBtn').onclick = function() {
        // Kirim request untuk menghapus customer (misalnya melalui AJAX atau redirect ke controller)
        window.location.href = "<?php echo site_url('dashboard/do_delete_supplier/'); ?>" + supplierId;
    };

    // Menampilkan modal delete
    $('#deleteSupplierModal').modal('show');
}
</script>
<script>
    // Fungsi untuk menampilkan data customer yang ingin diedit di dalam modal
    function editCustomer(customerId) {
        // Menggunakan AJAX untuk mengambil data customer berdasarkan ID
        $.ajax({
    url: "<?php echo site_url('dashboard/get_customer_by_id/'); ?>" + customerId,
    method: "GET",
    dataType: "json",
    success: function(response) {
        // Debug: Periksa data yang diterima dari server
        console.log(response);

        $('#customer_id').val(response.id);
        $('#name_customers').val(response.name_customers);
        $('#phone').val(response.phone);
        $('#Jenis_kelamin').val(response.Jenis_kelamin);
        
        // Menampilkan modal
        $('#editCustomerModal').modal('show');
    }
});

    }

    // Fungsi untuk menampilkan data supplier yang ingin diedit di dalam modal
    function editSupplier(supplierId) {
        // Menggunakan AJAX untuk mengambil data customer berdasarkan ID
        $.ajax({
    url: "<?php echo site_url('dashboard/get_supplier_by_id/'); ?>" +supplierId,
    method: "GET",
    dataType: "json",
    success: function(response) {
        // Debug: Periksa data yang diterima dari server
        console.log(response);

        $('#supplier_id').val(response.id_suppliers);
        $('#name_suppliers').val(response.name_suppliers);
        $('#phone').val(response.phone);
        $('#alamat').val(response.alamat);
        
        // Menampilkan modal
        $('#editSupplierModal').modal('show');
    }
});

    }
</script>
<script>
    // Fungsi untuk pencarian customer
    function searchCustomer() {
        let input = document.getElementById('searchInputCustomer').value.toLowerCase();
        let table = document.getElementById('customerTable');
        let rows = table.getElementsByTagName('tr');

        // Looping melalui baris tabel dan menyembunyikan baris yang tidak sesuai dengan pencarian
        for (let i = 1; i < rows.length; i++) {
            let cells = rows[i].getElementsByTagName('td');
            let name = cells[0].textContent.toLowerCase();
            let phone = cells[1].textContent.toLowerCase();

            if (name.indexOf(input) > -1 || phone.indexOf(input) > -1) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }

  // Fungsi untuk mencetak data per baris
function printRowDataCustomer(customerId) {
    // Ambil elemen baris berdasarkan ID
    let row = document.getElementById('row_customers' + customerId);

    if (row) {
        // Dapatkan HTML dari baris yang ingin dicetak
        let content = row.outerHTML;

        // Buka jendela baru untuk mencetak
        let printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Cetak Data Customer</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
        printWindow.document.write('</head><body>');
        printWindow.document.write(content); // Tulis data yang akan dicetak
        printWindow.document.write('</body></html>');
        printWindow.document.close(); // Menutup dokumen
        printWindow.print(); // Melakukan proses print
    } else {
        console.log("Baris dengan ID 'row_customers" + customerId + "' tidak ditemukan!");
    }
}

// Fungsi untuk mencetak seluruh tabel
function printAllDataCustomer() {
    // Ambil seluruh tabel
    let table = document.getElementById('customerTable');

    if (table) {
        // Sembunyikan kolom aksi pada setiap baris
        let rows = table.getElementsByTagName('tr');
        for (let i = 0; i < rows.length; i++) {
            let actionColumn = rows[i].querySelector('td:last-child');
            if (actionColumn) {
                actionColumn.style.display = 'none'; // Menyembunyikan kolom aksi
            }
        }

        // Ambil tanggal saat ini
        let currentDate = new Date();
        let dateString = currentDate.toISOString().split('T')[0]; // Format: YYYY-MM-DD

        // Buka jendela baru untuk mencetak
        let printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Cetak Semua Data Customer - ' + dateString + '</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
        printWindow.document.write('<style>body { font-family: Arial, sans-serif; margin: 20px; }');
        printWindow.document.write('td, th { padding: 8px; text-align: left; border: 1px solid #ddd; }');
        printWindow.document.write('table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }');
        printWindow.document.write('td:last-child, th:last-child { display: none; }</style>'); // CSS inline untuk menyembunyikan kolom aksi
        printWindow.document.write('</head><body>');
        printWindow.document.write(table.outerHTML); // Tulis seluruh tabel untuk dicetak
        printWindow.document.write('</body></html>');
        printWindow.document.close(); // Menutup dokumen
        printWindow.print(); // Melakukan proses print

        // Kembalikan tampilan kolom aksi setelah mencetak
        for (let i = 0; i < rows.length; i++) {
            let actionColumn = rows[i].querySelector('td:last-child');
            if (actionColumn) {
                actionColumn.style.display = ''; // Menampilkan kembali kolom aksi
            }
        }
    } else {
        console.log("Tabel customer tidak ditemukan!");
    }
}


    // Fungsi untuk pencarian supplier
    function searchSupplier() {
        let input = document.getElementById('searchInputSupplier').value.toLowerCase();
        let table = document.getElementById('supplierTable');
        let rows = table.getElementsByTagName('tr');

        // Looping melalui baris tabel dan menyembunyikan baris yang tidak sesuai dengan pencarian
        for (let i = 1; i < rows.length; i++) {
            let cells = rows[i].getElementsByTagName('td');
            let name = cells[0].textContent.toLowerCase();
            let phone = cells[1].textContent.toLowerCase();

            if (name.indexOf(input) > -1 || phone.indexOf(input) > -1) {
                rows[i].style.display = '';
            } else {
                rows[i].style.display = 'none';
            }
        }
    }

  // Fungsi untuk mencetak data per baris
function printRowDataSupplier(supplierId) {
    // Ambil elemen baris berdasarkan ID
    let row = document.getElementById('row_suppliers' + supplierId);

    if (row) {
        // Hapus kolom aksi dari baris sebelum mencetak
        let actionColumn = row.querySelector('td:last-child');
        if (actionColumn) {
            actionColumn.style.display = 'none'; // Menyembunyikan kolom aksi
        }

        // Dapatkan HTML dari baris yang ingin dicetak
        let content = row.outerHTML;

        // Buka jendela baru untuk mencetak
        let printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Cetak Data Supplier</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
        printWindow.document.write('<style>td:last-child, th:last-child { display: none; }</style>'); // CSS inline untuk menyembunyikan kolom aksi
        printWindow.document.write('</head><body>');
        printWindow.document.write(content); // Tulis data yang akan dicetak
        printWindow.document.write('</body></html>');
        printWindow.document.close(); // Menutup dokumen
        printWindow.print(); // Melakukan proses print

        // Kembalikan tampilan kolom aksi setelah mencetak
        actionColumn.style.display = ''; // Menampilkan kembali kolom aksi
    } else {
        console.log("Baris dengan ID 'row_suppliers" + supplierId + "' tidak ditemukan!");
    }
}

// Fungsi untuk mencetak seluruh tabel
function printAllDataSupplier() {
    // Ambil seluruh tabel
    let table = document.getElementById('supplierTable');

    if (table) {
        // Sembunyikan kolom aksi pada setiap baris
        let rows = table.getElementsByTagName('tr');
        for (let i = 0; i < rows.length; i++) {
            let actionColumn = rows[i].querySelector('td:last-child');
            if (actionColumn) {
                actionColumn.style.display = 'none'; // Menyembunyikan kolom aksi
            }
        }

        // Ambil tanggal saat ini
        let currentDate = new Date();
        let dateString = currentDate.toISOString().split('T')[0]; // Format: YYYY-MM-DD

        // Buka jendela baru untuk mencetak
        let printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Cetak Semua Data Supplier - ' + dateString + '</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
        printWindow.document.write('<style>body { font-family: Arial, sans-serif; margin: 20px; }');
        printWindow.document.write('td, th { padding: 8px; text-align: left; border: 1px solid #ddd; }');
        printWindow.document.write('table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }');
        printWindow.document.write('td:last-child, th:last-child { display: none; }</style>'); // CSS inline untuk menyembunyikan kolom aksi
        printWindow.document.write('</head><body>');
        printWindow.document.write(table.outerHTML); // Tulis seluruh tabel untuk dicetak
        printWindow.document.write('</body></html>');
        printWindow.document.close(); // Menutup dokumen
        printWindow.print(); // Melakukan proses print

        // Kembalikan tampilan kolom aksi setelah mencetak
        for (let i = 0; i < rows.length; i++) {
            let actionColumn = rows[i].querySelector('td:last-child');
            if (actionColumn) {
                actionColumn.style.display = ''; // Menampilkan kembali kolom aksi
            }
        }
    } else {
        console.log("Tabel supplier tidak ditemukan!");
    }
}



</script>




</body>
</html>