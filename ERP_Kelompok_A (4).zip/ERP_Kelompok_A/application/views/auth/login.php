<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
    <style>
        /* Reset CSS */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(to right, #ff6600, #000); /* Gradien orange ke hitam */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: rgba(0, 0, 0, 0.7); /* Transparan hitam untuk efek modern */
            border-radius: 12px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .login-container:hover {
            transform: translateY(-10px); /* Efek hover untuk tampilan lebih dinamis */
        }

        .login-container h2 {
            color: #ff6600; /* Warna heading orange */
            margin-bottom: 20px;
            font-size: 26px;
        }

        .login-container img {
            width: 120px;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .login-container img:hover {
            transform: rotate(360deg); /* Efek rotasi gambar logo */
        }

        .login-container label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
            color: #fff;
            font-size: 16px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background-color: #333;
            color: #fff;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .login-container input:focus {
            border-color: #ff6600;
            background-color: #444;
            outline: none;
        }

        .login-container button {
            width: 100%;
            padding: 15px;
            background-color: #ff6600;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .login-container button:hover {
            background-color: #e55b00;
            transform: scale(1.05); /* Efek tombol membesar saat hover */
        }

        .error-message {
            color: red;
            margin-bottom: 20px;
            font-size: 14px;
            animation: fadeIn 1s ease-in;
        }

        /* Animasi muncul pesan error */
        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        /* Responsive Design */
        @media (max-width: 600px) {
            .login-container {
                padding: 25px;
            }
            .login-container h2 {
                font-size: 22px;
            }
            .login-container button {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <img src="<?php echo base_url('assets/logo/logo_buckup.png')?>" alt="Logo"> <!-- Ganti dengan logo Anda -->
        <h2>Login Admin</h2>
        
        <!-- Menampilkan pesan error jika ada -->
        <?php if ($this->session->flashdata('error')): ?>
            <p class="error-message"><?php echo $this->session->flashdata('error'); ?></p>
        <?php endif; ?>

        <!-- Form login -->
        <form action="<?php echo site_url('auth/do_login'); ?>" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
