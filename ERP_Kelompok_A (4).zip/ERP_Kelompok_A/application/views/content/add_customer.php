<div class="content" style="padding: 70px; background-color: #f9f9f9; border-radius: 8px;">
    <h1 style="font-size: 24px; color: #333; margin-bottom: 20px;">Tambah Customer</h1>

    <form action="<?php echo site_url('dashboard/do_add_customer'); ?>" method="POST">
    <div class="form-group" style="margin-bottom: 15px;">
    <label for="name_customers" style="font-size: 16px; color: #555;">Nama</label>
    <input type="text" id="name_customers" name="name_customers" class="form-control" required
        style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; box-sizing: border-box;">
</div>

<div class="form-group" style="margin-bottom: 15px;">
    <label for="phone" style="font-size: 16px; color: #555;">Telepon</label>
    <input type="text" id="phone" name="phone" class="form-control" required
        style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; box-sizing: border-box;">
</div>

<div class="form-group" style="margin-bottom: 20px;">
    <label for="Jenis_kelamin" style="font-size: 16px; color: #555;">Jenis Kelamin</label>
    <select id="Jenis_kelamin" name="Jenis_kelamin" class="form-control" required
        style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; box-sizing: border-box;">
        <option value="L">Laki-laki</option>
        <option value="P">Perempuan</option>
    </select>
</div>

        <div style="display: flex; gap: 10px; justify-content: flex-end; width: 100%; align-items: center;">
    <button type="submit" class="btn btn-primary" style="background-color: #007bff; color: #fff; border: none; padding: 12px 25px; border-radius: 4px; font-size: 16px; width: 15%; cursor: pointer;">
        Simpan
    </button>
    <a href="<?php echo site_url('dashboard/customers'); ?>" class="btn btn-secondary" style="background-color: red; color: #fff; padding: 12px 25px; border-radius: 4px; text-decoration: none; font-size: 16px; width: 5%; text-align: center; display: inline-block; cursor: pointer;">
        Batal
    </a>
</div>

    </form>
</div>
