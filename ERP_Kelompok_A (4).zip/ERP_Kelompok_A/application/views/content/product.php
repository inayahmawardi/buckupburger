<div class="content">
    <h1>Daftar Produk</h1>

    <!-- Tombol Tambah Produk -->
    <a href="<?php echo site_url('dashboard/add_product'); ?>" class="btn btn-primary mb-4">Tambah Produk</a>

    <!-- Form Pencarian -->
    <form id="searchForm" class="mb-4" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div style="flex: 1; margin-right: 20px;">
            <input type="text" class="form-control" id="searchInputProduct" placeholder="Cari berdasarkan nama atau harga..." onkeyup="searchProduct()" 
                style="padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px; width: 100%; box-sizing: border-box;">
        </div>
        <div>
            <!-- Tombol Print Semua Data -->
            <button type="button" class="btn btn-success" onclick="printAllDataProduct()" 
                style="background-color: orange; color: white; padding: 10px 20px; border-radius: 5px; border: none; font-size: 16px; cursor: pointer;"> 
                <i class="fas fa-print"></i> Print Semua Data
            </button>
        </div>
    </form>

    <!-- Tabel Produk dengan Bootstrap -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered" id="productTable">
            <thead class="thead-dark">
                <tr>
                    <th style="text-align: center;">Nama Produk</th>
                    <th style="text-align: center;">Harga</th>
                    <th style="text-align: center;">Stok</th>
                    <th style="text-align: center;">Supplier</th>
                    <th style="text-align: center;">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $product): ?>
                        <tr id="row_products<?php echo $product->id; ?>" class="product-row">
                            <td style="text-align: center;"><?php echo $product->name_product; ?></td>
                            <td style="text-align: center;"><?php echo $product->price; ?></td>
                            <td style="text-align: center;"><?php echo $product->stock; ?></td>
                            <td style="text-align: center;"><?php echo $product->supplier_name ?? 'N/A'; ?></td>
                            <td style="text-align: center;">
                                <!-- Tombol Edit dengan Ikon -->
                                <button type="button" class="btn btn-warning btn-sm" onclick="editProduct(<?php echo $product->id; ?>)" style="background-color: #009990; color: white">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <!-- Tombol Hapus dengan Ikon -->
                                <button href="javascript:void(0);" class="btn btn-danger btn-sm" onclick="deleteProduct(<?php echo $product->id; ?>)" style="background-color: #FA4032; color: white">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </button>
                                <!-- Tombol Print Baris -->
                                <button type="button" class="btn btn-info btn-sm" onclick="printRowDataProduct(<?php echo $product->id; ?>)" style="background-color: #17a2b8; color: white">
                                    <i class="fas fa-print"></i> Print
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada data produk</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Edit Produk -->
<div class="modal fade" id="editProductModal" tabindex="-1" role="dialog" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #007bff; color: white; border-bottom: none; border-radius: 10px;">
                <h5 class="modal-title" id="editProductModalLabel"><i class="fas fa-edit"></i> Edit Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: red;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 20px;">
                <form id="editProductForm" action="<?php echo site_url('dashboard/do_edit_product'); ?>" method="POST">
                    <input type="hidden" name="product_id" id="product_id">
                    
                    <div class="form-group">
                        <label for="name_product">Nama Produk</label>
                        <input type="text" class="form-control" id="name_product" name="name_product" required placeholder="Masukkan Nama Produk">
                    </div>
                    
                    <div class="form-group">
                        <label for="price">Harga</label>
                        <input type="number" class="form-control" id="price" name="price" required placeholder="Masukkan Harga">
                    </div>

                    <div class="form-group">
                        <label for="stock">Stok</label>
                        <input type="number" class="form-control" id="stock" name="stock" required placeholder="Masukkan Jumlah Stok">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Simpan Perubahan</button>
                    <button type="button" class="btn btn-secondary btn-block" data-dismiss="modal">Batal</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Hapus Produk -->
<div class="modal fade" id="deleteProductModal" tabindex="-1" role="dialog" aria-labelledby="deleteProductModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="border-radius: 8px; border: 1px solid #ddd; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
            <div class="modal-header" style="background-color: #f8d7da; border-bottom: none; color: #721c24; font-weight: bold; border-radius: 10px;">
                <h5 class="modal-title" id="deleteProductModalLabel"><i class="fas fa-trash-alt"></i> Hapus Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: red;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 20px; font-size: 16px; color: #333; text-align: center;">
                <p>Apakah Anda yakin ingin menghapus produk ini?</p>
            </div>
            <div class="modal-footer" style="display: flex; justify-content: center; padding: 20px;">
                <button type="button" class="btn btn-danger" id="confirmDeleteProductBtn" style="background-color: #dc3545; color: white; border-radius: 30px; font-size: 16px; padding: 10px 20px; transition: background-color 0.3s ease;">Hapus</button>
            </div>
        </div>
    </div>
</div>

<script>
    function searchProduct() {
        var query = document.getElementById('searchInputProduct').value;

        // AJAX request
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '<?php echo site_url('dashboard/search_product'); ?>', true);
        xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (this.status == 200) {
                document.querySelector('#productTable tbody').innerHTML = this.responseText;
            }
        };
        xhr.send('query=' + query);
    }

    function editProduct(productId) {
        // Logic untuk mengambil data produk berdasarkan productId dan menampilkan di modal edit
    }

    function deleteProduct(productId) {
        // Logic untuk menampilkan modal konfirmasi hapus
    }
</script>
