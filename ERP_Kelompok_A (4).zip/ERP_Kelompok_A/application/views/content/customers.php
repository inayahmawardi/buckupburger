<div class="content">
    <h1>Daftar Customer</h1>

    <!-- Tombol Tambah Customer -->
    <a href="<?php echo site_url('dashboard/add_customer'); ?>" class="btn btn-primary mb-4">Tambah Customer</a>

    <!-- Form Pencarian -->
    <form id="searchForm" class="mb-4" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div style="flex: 1; margin-right: 20px;">
            <input type="text" class="form-control" id="searchInputCustomer" placeholder="Cari berdasarkan nama atau telepon..." onkeyup="searchCustomer()" 
                style="padding: 10px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px; width: 100%; box-sizing: border-box;">
        </div>
        <div>
            <!-- Tombol Print Semua Data -->
            <button type="button" class="btn btn-success" onclick="printAllDataCustomer()" 
                style="background-color: orange; color: white; padding: 10px 20px; border-radius: 5px; border: none; font-size: 16px; cursor: pointer;"> 
                <i class="fas fa-print"></i> Print Semua Data
            </button>
        </div>
    </form>

    <!-- Tabel Customer dengan Bootstrap -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered" id="customerTable">
            <thead class="thead-dark">
                <tr>
                    <th style="text-align: center;">Nama</th>
                    <th style="text-align: center;">Telepon</th>
                    <th style="text-align: center;">Jenis Kelamin</th>
                    <th style="text-align: center;">AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customers)): ?>
                    <?php foreach ($customers as $customer): ?>
                        <tr id="row_customers<?php echo $customer->id; ?>" class="customer-row">
                            <td style="text-align: center;"><?php echo $customer->name_customers; ?></td>
                            <td style="text-align: center;"><?php echo $customer->phone; ?></td>
                            <td style="text-align: center;"><?php echo $customer->Jenis_kelamin; ?></td>
                            <td style="text-align: center;">
                                <!-- Tombol Edit dengan Ikon -->
                                <button type="button" class="btn btn-warning btn-sm" onclick="editCustomer(<?php echo $customer->id; ?>)" style="background-color: #009990; color: white">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <!-- Tombol Hapus dengan Ikon -->
                                <button href="javascript:void(0);" class="btn btn-danger btn-sm" onclick="deleteCustomer(<?php echo $customer->id; ?>)" style="background-color: #FA4032; color: white">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </button>
                                <!-- Tombol Print Baris -->
                                <button type="button" class="btn btn-info btn-sm" onclick="printRowDataCustomer(<?php echo $customer->id; ?>)" style="background-color: #17a2b8; color: white">
                                    <i class="fas fa-print"></i> Print
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" class="text-center">Tidak ada data customer</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<!-- Modal Edit Customer -->
<div class="modal fade" id="editCustomerModal" tabindex="-1" role="dialog" aria-labelledby="editCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #007bff; color: white; border-bottom: none; border-radius: 10px;">
                <h5 class="modal-title" id="editCustomerModalLabel"><i class="fas fa-edit"></i> Edit Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: red;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 20px;">
                <form id="editCustomerForm" action="<?php echo site_url('dashboard/do_edit_customer'); ?>" method="POST">
                    <input type="hidden" name="customer_id" id="customer_id">
                    
                    <div class="form-group">
                        <label for="name_customers">Nama Customer</label>
                        <input type="text" class="form-control" id="name_customers" name="name_customers" required placeholder="Masukkan Nama Customer">
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" required placeholder="Masukkan Nomor Telepon">
                    </div>

                    <div class="form-group">
                        <label for="Jenis_kelamin">Jenis Kelamin</label>
                        <select id="Jenis_kelamin" name="Jenis_kelamin" class="form-control" required>
                            <option value="L">Laki-laki</option>
                            <option value="P">Perempuan</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Simpan Perubahan</button>
                    <button type="button" class="btn btn-secondary btn-block" data-dismiss="modal">Batal</button>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal Konfirmasi Hapus Customer -->
<div class="modal fade" id="deleteCustomerModal" tabindex="-1" role="dialog" aria-labelledby="deleteCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="border-radius: 8px; border: 1px solid #ddd; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
            <div class="modal-header" style="background-color: #f8d7da; border-bottom: none; color: #721c24; font-weight: bold; border-radius: 10px;">
                <h5 class="modal-title" id="deleteCustomerModalLabel"><i class="fas fa-trash-alt"></i> Hapus Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: red;">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="padding: 20px; font-size: 16px; color: #333; text-align: center;">
                <p>Apakah Anda yakin ingin menghapus customer ini?</p>
            </div>
            <div class="modal-footer" style="display: flex; justify-content: center; padding: 20px;">
                <button type="button" class="btn btn-danger" id="confirmDeleteCustomerBtn" style="background-color: #dc3545; color: white; border-radius: 30px; font-size: 16px; padding: 10px 20px; transition: background-color 0.3s ease;">Hapus</button>
            </div>
        </div>
    </div>
</div>




