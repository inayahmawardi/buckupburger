<!-- application/views/content/profile.php -->

<div class="container">
    <h2>Profile Admin</h2>
    <div class="card">
        <div class="card-header">
            <h4>Profil Admin</h4>
        </div>
        <div class="card-body">
            <p><strong>Username:</strong> <?php echo $admin->username; ?></p>
            <p><strong>Nama:</strong> <?php echo $admin->name; ?></p>
            <p><strong>Email:</strong> <?php echo $admin->email; ?></p>
            <!-- Menampilkan informasi lain sesuai yang ada di database -->
        </div>
        <div class="card-footer">
            <a href="<?php echo base_url('dashboard'); ?>" class="btn btn-primary">Kembali ke Dashboard</a>
        </div>
    </div>
</div>
