<?php
class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('Admin_model');
    }

    // Halaman login
    public function login() {
        // Cek jika sudah login
        if ($this->session->userdata('admin_id')) {
            redirect('dashboard'); // Jika sudah login, redirect ke dashboard
        }

        // Tampilkan form login
        $this->load->view('auth/login');
    }

    // Proses login
    public function do_login() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        // Validasi login
        $admin = $this->Admin_model->check_admin($username, $password);
        if ($admin) {
            // Set session jika login berhasil
            $this->session->set_userdata('admin_id', $admin->id);
            $this->session->set_userdata('username', $admin->username);
            redirect('dashboard');
        } else {
            // Jika login gagal, tampilkan pesan error
            $this->session->set_flashdata('error', 'Username atau password salah');
            redirect('auth/login');
        }
    }

    // Logout
    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}
