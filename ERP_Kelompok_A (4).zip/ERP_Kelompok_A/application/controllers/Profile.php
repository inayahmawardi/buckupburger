<?php
class Profile extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index() {
        // Misalnya, kita dapat mengambil ID pengguna dari session
        $user_id = $this->session->userdata('user_id');

        // Atau bisa juga ambil berdasarkan username jika menggunakan session
        // $username = $this->session->userdata('username');

        // Ambil data pengguna berdasarkan ID
        $data['user'] = $this->User_model->get_user_by_id($user_id);

        // Atau jika menggunakan username
        // $data['user'] = $this->User_model->get_user_by_username($username);

        // Load view untuk menampilkan profil
        $this->load->view('profile_view', $data);
    }
}
