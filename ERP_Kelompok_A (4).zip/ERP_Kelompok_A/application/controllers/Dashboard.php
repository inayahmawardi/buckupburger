<?php
class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Product_model');
        $this->load->model('Supplier_model');
        $this->load->model('Customer_model');
        $this->load->model('User_model'); // Model untuk data admin
        $this->load->library('session');

        // Cek apakah admin sudah login
        if (!$this->session->userdata('admin_id')) {
            redirect('auth/login');
        }
    }

    // Halaman Dashboard Utama
    public function index() {
        $data['products'] = $this->Product_model->get_all_products(); // Semua produk
        $data['total_customers'] = $this->Customer_model->get_total_customers(); // Total pelanggan
        $data['total_suppliers'] = $this->Supplier_model->get_total_suppliers(); // Total supplier
        $data['months'] = ['January', 'February', 'March', 'April', 'May']; // Data bulan
        $data['sales_data'] = [150, 200, 250, 300, 350]; // Data penjualan

        // Load view
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('admin/dashboard', $data); // Dashboard utama
        $this->load->view('admin/footer');
    }

    // ============================
    // SECTION: CUSTOMER MANAGEMENT
    // ============================
    public function customers() {
        $data['customers'] = $this->Customer_model->get_all_customers();
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/customers', $data);
        $this->load->view('admin/footer');
    }

    public function add_customer() {
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/add_customer');
        $this->load->view('admin/footer');
    }

    public function do_add_customer() {
        $data = [
            'name_customers' => $this->input->post('name_customers'),
            'phone' => $this->input->post('phone'),
            'Jenis_kelamin' => $this->input->post('Jenis_kelamin'),
        ];
        $this->Customer_model->add_customer($data);
        redirect('dashboard/customers');
    }

    public function do_edit_customer() {
        $customer_id = $this->input->post('customer_id');
        $data = [
            'name_customers' => $this->input->post('name_customers'),
            'phone' => $this->input->post('phone'),
            'Jenis_kelamin' => $this->input->post('Jenis_kelamin'),
        ];
        $this->Customer_model->update_customer($customer_id, $data);
        redirect('dashboard/customers');
    }

    public function do_delete_customer($customer_id) {
        $this->Customer_model->delete_customer($customer_id);
        redirect('dashboard/customers');
    }

    public function get_customer_by_id($customer_id) {
        $customer = $this->Customer_model->get_customer_by_id($customer_id);
        echo json_encode($customer);
    }

    // ============================
    // SECTION: SUPPLIER MANAGEMENT
    // ============================
    public function suppliers() {
        $data['suppliers'] = $this->Supplier_model->get_all_suppliers();
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/suppliers', $data);
        $this->load->view('admin/footer');
    }

    public function add_supplier() {
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/add_supplier');
        $this->load->view('admin/footer');
    }

    public function do_add_supplier() {
        $data = [
            'name_suppliers' => $this->input->post('name_suppliers'),
            'phone' => $this->input->post('phone'),
            'alamat' => $this->input->post('alamat'),
        ];
        $this->Supplier_model->add_supplier($data);
        redirect('dashboard/suppliers');
    }

    public function do_edit_supplier() {
        $supplier_id = $this->input->post('supplier_id');
        $data = [
            'name_suppliers' => $this->input->post('name_suppliers'),
            'phone' => $this->input->post('phone'),
            'alamat' => $this->input->post('alamat'),
        ];
        $this->Supplier_model->update_supplier($supplier_id, $data);
        redirect('dashboard/suppliers');
    }

    public function do_delete_supplier($supplier_id) {
        $this->Supplier_model->delete_supplier($supplier_id);
        redirect('dashboard/suppliers');
    }

    public function get_supplier_by_id($supplier_id) {
        $supplier = $this->Supplier_model->get_supplier_by_id($supplier_id);
        echo json_encode($supplier);
    }

    // ============================
    // SECTION: PRODUCT MANAGEMENT
    // ============================
    public function products() {
        $data['products'] = $this->Product_model->get_all_products();
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/product', $data);
        $this->load->view('admin/footer');
    }

    public function add_product() {
        $this->load->model('Supplier_model');
        $data['suppliers'] = $this->Supplier_model->get_all_suppliers(); // Ambil data supplier untuk dropdown
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/add_product', $data);
        $this->load->view('admin/footer');
    }

    public function do_add_product() {
        $data = [
            'name_product' => $this->input->post('name_product'),
            'price' => $this->input->post('price'),
            'stock' => $this->input->post('stock'),
            'id_supplier' => $this->input->post('id_supplier'),
        ];
        $this->Product_model->add_product($data);
        redirect('dashboard/products');
    }

    public function edit_product($id) {
        $data['product'] = $this->Product_model->get_product_by_id($id);
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/edit_product', $data);
        $this->load->view('admin/footer');
    }

    public function do_edit_product() {
        $product_id = $this->input->post('product_id');
        $data = [
            'name_product' => $this->input->post('name_product'),
            'price' => $this->input->post('price'),
            'stock' => $this->input->post('stock'),
            'id_supplier' => $this->input->post('id_supplier'),
        ];
        $this->Product_model->update_product($product_id, $data);
        redirect('dashboard/products');
    }

    public function do_delete_product($id) {
        $this->Product_model->delete_product($id);
        redirect('dashboard/products');
    }

    // ============================
    // SECTION: PROFILE AND LOGOUT
    // ============================
    public function profile() {
        $admin_id = $this->session->userdata('admin_id');
        $data['admin'] = $this->User_model->get_admin_by_id($admin_id);
        $this->load->view('admin/header');
        $this->load->view('admin/sidebar');
        $this->load->view('content/profile', $data);
        $this->load->view('admin/footer');
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth/login');
    }
}
?>
