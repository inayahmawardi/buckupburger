<?php 

class Transaksi_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Menambahkan transaksi baru ke database
    public function add_transaksi($data) {
        $this->db->insert('transaksi', $data); 
    }

    // Update transaksi
    public function update_transaksi($transaksi_id, $data) {
        $this->db->where('id_transaksi', $transaksi_id);
        $this->db->update('transaksi', $data);
    }    

    // Hapus transaksi
    public function delete_transaksi($transaksi_id) {
        $this->db->where('id_transaksi', $transaksi_id);
        $this->db->delete('transaksi');
    }

    // Mengambil semua data transaksi
    public function get_all_transaksi() {
        $this->db->select('id_transaksi, id_produk, id_customers, tgl');
        $this->db->from('transaksi');
        $this->db->where('1');  // Kondisi '1' yang berarti selalu benar
        $query = $this->db->get();
        return $query->result();
    }

    // Mengambil total transaksi
    public function get_total_transaksi() {
        return $this->db->count_all('transaksi');
    }

    // Mengambil transaksi berdasarkan ID
    public function get_transaksi_by_id($transaksi_id) {
        $this->db->where('id_transaksi', $transaksi_id);
        $query = $this->db->get('transaksi');
        return $query->row(); 
    }
}
?>
