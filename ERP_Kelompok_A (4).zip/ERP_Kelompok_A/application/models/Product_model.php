<?php
class Product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Ambil semua produk
    public function get_all_products() {
        $query = $this->db->get('products'); // Nama tabel 'products'
        return $query->result(); // Kembalikan sebagai array objek
    }

    // Ambil produk berdasarkan ID
    public function get_product_by_id($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('products');
        return $query->row(); // Kembalikan satu baris data sebagai objek
    }

    // Tambah produk baru
    public function add_product($data) {
        if ($this->db->insert('products', $data)) {
            return $this->db->insert_id(); // Kembalikan ID produk yang baru ditambahkan
        } else {
            return false;
        }
    }

    // Update produk berdasarkan ID
    public function update_product($id, $data) {
        $this->db->where('id', $id);
        if ($this->db->update('products', $data)) {
            return true; // Kembalikan true jika berhasil
        } else {
            return false; // Kembalikan false jika gagal
        }
    }

    // Hapus produk berdasarkan ID
    public function delete_product($id) {
        $this->db->where('id', $id);
        if ($this->db->delete('products')) {
            return true; // Kembalikan true jika berhasil
        } else {
            return false; // Kembalikan false jika gagal
        }
    }

    // Ambil total jumlah produk
    public function get_total_products() {
        return $this->db->count_all('products'); // Hitung total jumlah data di tabel 'products'
    }

    // Ambil produk dengan filter (contoh dengan supplier)
    public function get_products_by_supplier($supplier_id) {
        $this->db->where('id_supplier', $supplier_id);
        $query = $this->db->get('products');
        return $query->result(); // Kembalikan sebagai array objek
    }

    // Ambil produk dengan filter harga
    public function get_products_by_price_range($min_price, $max_price) {
        $this->db->where('price >=', $min_price);
        $this->db->where('price <=', $max_price);
        $query = $this->db->get('products');
        return $query->result(); // Kembalikan produk dalam rentang harga
    }

    // Ambil produk dengan pencarian nama
    public function search_products_by_name($name) {
        $this->db->like('name_product', $name); // Pencarian menggunakan LIKE
        $query = $this->db->get('products');
        return $query->result(); // Kembalikan hasil pencarian
    }
}
?>
