<?php
class Admin_model extends CI_Model {

    // Mengecek apakah admin ada di database
    public function check_admin($username, $password) {
        $this->db->where('username', $username);
        $this->db->where('password', md5($password)); // Gantilah dengan metode hash password yang lebih aman
        $query = $this->db->get('admins');
        return $query->row();
    }
}
